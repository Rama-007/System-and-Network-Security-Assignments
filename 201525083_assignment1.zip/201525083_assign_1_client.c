#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#define PORT 18000
#include <unistd.h>
#include <math.h>
#include <ctype.h>
#include <limits.h>

int prime_factors[1024];

char dict[]={' ','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',',','.','?','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!'};

int power(int a, int q,int n)
{
	int ans=1;
	while(q>0)
	{
		if(q&1)
		{
			ans=(ans*a)%n;
		}
		a=(a*a)%n;
		q=q>>1;
	}
	return ans;
}

int MillerRobinTest(int prime)
{
	int q=prime-1,j=0,k=0;
	while(q%2==0)
	{
		q=q/2;
		k+=1;
	}
	int a= 1+rand()%(prime-1);
	if(power(a,q,prime)%prime==1)
	{
		return 1;
	}
	for(j=1;j<=k-1;j++)
	{
		//a^((2^j).q)
		int temp=(power(a,(power(2,j,prime)*q)%prime,prime))%prime;
		if(temp==prime-1 || temp==1)
		{
			return 1;
		}
	}
	return 0;

}

int generate_prime()
{
	srand(time(NULL));
	while(1)
	{
		int counter=7;
		int prime=rand()% INT_MAX;
		if(prime%2==0)
			prime+=1;
		int flag=0;
		while(counter--)
		{
			if(!(MillerRobinTest(prime)))
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			if(prime>10000)
				return prime;
		}
	}
}


void prime_factor(int p)
{
	int l=0,r;
	if(p%2==0)
	{
		prime_factors[l]=2;
		l++;
		while(p%2==0)
			p=p/2;
	}
	for(r=3;r<=sqrt(p);r=r+2)
	{
		if(p%r==0)
		{
			prime_factors[l]=r;
			l++;
			while(p%r==0)
				p=p/r;
		}
	}
	if(p>2)
		prime_factors[l]=p;
}

int primitive_prime(int prime)
{
	int p=prime-1,r;
	for(r=2;r<=p;r++)
	{
		int flag=0,i;
		for(i=0;i<1024;i++)
		{
			if(prime_factors[i]==0)
				break;
			if(power(r,p/prime_factors[i],prime)==1)
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
			return r;
	}
	return -1;
}

int main(int argc, char *argv[])
{
	struct sockaddr_in address;
	struct sockaddr_in serv_address;
	int sock=0,value;
	char buffer[1024]={0},buffer1[1024]={0};
	if((sock=socket(AF_INET,SOCK_STREAM,0))<0)
	{
		perror("socket");
		exit(0);
	}
	memset(&serv_address,'0',sizeof(serv_address));
	serv_address.sin_family=AF_INET;
	serv_address.sin_port=htons(PORT);
	if(inet_pton(AF_INET,"127.0.0.1",&serv_address.sin_addr)<=0)
	{
		perror("INET_Address");
		exit(0);
	}
	if(connect(sock,(struct sockaddr *)&serv_address,sizeof(serv_address))<0)
	{
		perror("connection error");
		exit(0);
	}
	int l=0,i,m,j;
	memset(prime_factors,0,1024);
	int prime=generate_prime();
	prime_factor(prime-1);
	int primitive_root=primitive_prime(prime);
	printf("Global Public Elements: ");
	printf("Prime--%d ", prime);
	printf("Primitive_root--%d\n", primitive_root);

	int private_key=rand()%prime;
	while(private_key==0)
		private_key=rand()%prime;

	int public_key=power(primitive_root,private_key,prime);
	printf("Public_key Ya--%d\n", public_key);

	sprintf(buffer,"%d %d %d\n",public_key,prime,primitive_root);
	send(sock,buffer,strlen(buffer),0);

	int Yb,val;
	val=read(sock,buffer,1024);
	sscanf(buffer,"%d\n",&Yb);
	printf("Yb- %d\n", Yb);
	int Kab=power(Yb,private_key,prime);
	printf("Kab-- %d\n", Kab);
	int key=Kab%67;
	while(1)
	{
		memset(buffer,'\0',1024);
		memset(buffer1,'\0',1024);
		fgets(buffer1,1024-1,stdin);
		printf("Sent-Plain-text\n%s\n",buffer1);
		for(i=0;i<strlen(buffer1);i++)
		{
			for(j=0;j<67;j++)
			{
				if(dict[j]==buffer1[i])
				{
					buffer1[i]=dict[(j+key)%67];
					break;
				}
			}
		}
		// if(buffer1[0]!='\n')
		// {
			if((send(sock,buffer1,strlen(buffer1),0))==-1)
			{
				perror("Sending error!");
				break;
			}
		// }
		// else
		// {
			value=recv(sock,buffer,sizeof(buffer),0);
			if(value<=0)
			{
				perror("receiving error!");
				break;
			}
			buffer[value]='\0';
			if(buffer[0]!='\n')
			{
				printf("Received-cipher-text:\n%s\n",buffer);
				for(i=0;i<strlen(buffer);i++)
				{
					for(j=0;j<67;j++)
					{
						if(dict[j]==buffer[i])
						{
							buffer[i]=dict[(j-key+67)%67];
							break;
						}
					}
				}
				printf("Decrypted-Plain-text:\n%s\n",buffer);
			}
		// }
		
		
	}

	
}