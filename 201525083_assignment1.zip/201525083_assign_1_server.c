#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#define PORT 18000
#include <unistd.h>
#include <math.h>
#include <ctype.h>
#include <limits.h>

int power(int a, int q,int n)
{
	int ans=1;
	while(q>0)
	{
		if(q&1)
		{
			ans=(ans*a)%n;
		}
		a=(a*a)%n;
		q=q>>1;
	}
	return ans;
}

char dict[]={' ','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',',','.','?','0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','!'};


int main(int argc, char *argv[])
{
	int server_fd,value,new_sock;
	struct sockaddr_in address;
	int addrlen=sizeof(address);
	char buffer[1024]={0},buffer1[1024]={0};
	int opt=1;
	if((server_fd=socket(AF_INET,SOCK_STREAM,0))==0)
	{
		perror("socket error");
		exit(0);
	}
	if(setsockopt(server_fd, SOL_SOCKET,SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
	{
		perror("setsockopt");
		exit(0);
	}
	address.sin_family=AF_INET;
	address.sin_port=htons(PORT);
	address.sin_addr.s_addr=INADDR_ANY;

	if(bind(server_fd, (struct sockaddr *)&address,sizeof(address))<0)
	{
		perror("bind");
		exit(0);
	}
	if(listen(server_fd,3)<0)
	{
		perror("listen");
		exit(0);
	}
	if((new_sock=accept(server_fd, (struct sockaddr *)&address, (socklen_t *) &addrlen))<0)
	{
		perror("accept");
		exit(0);
	}
	value=read(new_sock,buffer,1024);
	int prime,primitive,Ya;
	sscanf(buffer,"%d %d %d\n",&Ya,&prime,&primitive);
	printf("Ya--%d Prime--%d Primitive--%d\n",Ya,prime,primitive );
	int private_key=rand()%prime;
	while(private_key==0)
		private_key=rand()%prime;

	int public_key=power(primitive,private_key,prime);
	printf("Public_key Yb--%d\n", public_key);
	sprintf(buffer,"%d\n",public_key);
	send(new_sock,buffer,strlen(buffer),0);

	int Kba=power(Ya,private_key,prime);
	printf("Kba-- %d\n", Kba);
	int key=Kba%67,i,j;
	while(1)
	{
		memset(buffer,'\0',1024);
		memset(buffer1,'\0',1024);
		if((value=recv(new_sock,buffer,1024,0))<=0)
		{
			perror("receiving error!");
			break;
		}
		buffer[value]='\0';
		if(buffer[0]!='\n')
			{
				printf("Received-cipher-text:\n%s\n",buffer);
				for(i=0;i<strlen(buffer);i++)
				{
					for(j=0;j<67;j++)
					{
						if(dict[j]==buffer[i])
						{
							buffer[i]=dict[(j-key+67)%67];
							break;
						}
					}
				}
				printf("Decrypted-Plain-text:\n%s\n",buffer);
			}

		fgets(buffer1,1024-1,stdin);
		printf("Sent-Plain-text\n%s\n",buffer1);
		for(i=0;i<strlen(buffer1);i++)
		{
			for(j=0;j<67;j++)
			{
				if(dict[j]==buffer1[i])
				{
					buffer1[i]=dict[(j+key)%67];
					break;
				}
			}
		}
		// if(buffer1[0]!='\n')
		// {
			if((send(new_sock,buffer1,strlen(buffer1),0))==-1)
			{
				perror("sending!");
				break;
			}
		// }
		
	}
}