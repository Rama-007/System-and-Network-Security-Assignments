import random,time,hashlib

import socket,sys,pickle
sock=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

port=18000
sock.connect((sys.argv[1],port))

def power(a,q,n):
	a=int(a)
	q=int(q)
	n=int(n)
	return pow(a,q,n);

def MillerRabinTest(prime):
	q=prime-1;j=0;k=0;
	while(q%2==0):
		q=q/2;
		k+=1;
	a=1+random.randint(10**4,10**6)%(prime-1)
	if(power(a,q,prime)%prime==1):
		return 1;
	for j in range(1,k):
		#a^((2^j).q)
		temp=(power(a,(power(2,j,prime)*q)%prime,prime))%prime
		if (temp==prime-1 or temp==1):
			return 1;
	return 0;

def generate_prime():
	while True:
		counter=7
		prime=random.randint(10**4,10**5)
		if prime%2==0:
			prime+=1
		flag=0;
		while(counter):
			counter-=1
			if(not(MillerRabinTest(prime))):
				flag=1
				break
		if(flag==0):
			return prime

def findq(p):
	maxi=0;
	if(p%2==0):
		maxi=max(2,maxi)
		while(p%2==0):
			p=p/2
	for r in range(3,int(p**0.5)+1,2):
		if(p%r==0):
			maxi=max(r,maxi)
			while(p%r==0):
				p=p/r
	if(p>2):
		maxi=max(p,maxi);
	return int(maxi)


def rand_message():
	length=random.randint(1,1023)
	message=[]
	for i in range(0,length):
		message.append(str(random.randint(0,1)))
	return ''.join(message)


def get_sha(message):
	hash_obj=hashlib.sha1(message.encode())
	return int(hash_obj.hexdigest(),16)	

def inverse_modulo(q,p):
	return power(q,p-2,p);


def main():
	while True:
		q=0;
		p=0;
		#Key Generation Phase
		while(q<10000):
			p=generate_prime()
			q=findq(p-1)
		g=random.randint(2,p-2);
		alpha=power(q,int((p-1)/q),p);
		private_key=random.randint(2,q-1)
		y=power(alpha,private_key,p)
		print("Prime P: %d Prime q: %d alpha: %d y: %d\n" %(p,q,alpha,y));

		#Send PUBKEY
		data=pickle.dumps([p,q,alpha,y])
		sock.send(data)

		#Signature Generation Phase
		k=random.randint(2,q-1)
		r=power(alpha,k,p)
		print("k: %d r: %d" %(k,r))

		message=rand_message();
		print("Randomly generated message is: %s\n" %message);

		#m||r
		result=message+str(r)
		print("Concatenated m||r: %s\n" %result);

		#e,s
		e=get_sha(result)
		s=((private_key*(e%q)%q)+k)%q;
		print("e: %d s: %d\n" %(e,s));

		#u,v,e',s'
		while True:
			v=random.randint(1,q-1);u=random.randint(1,q-1);
			# print("u: %d v: %d\n" %(u,v));

			#r'=r α^−u y^v mod p.
			r_dash=((r*power(y,v,p))%p * inverse_modulo(power(alpha,u,p),p)%p);
			
			#m||r'
			result=message+str(r_dash)
			e_dash=get_sha(result)
			s_dash=s-u;
			if(s_dash<0):
				continue
			print("r': %d e': %d s': %d\n" %(r_dash,e_dash,s_dash));
			print("s: %d e: %d u: %d v: %d\n" %(s,e,u,v))
			print("e': %d e-v: %d\n" %(e_dash,(e-v)))
			print("e': %d e-v: %d\n" %(e_dash%(p-1),(e-v)%(p-1)))
			print("s': %d s-u: %d\n" %(s_dash,s-u))

			if(e_dash%(p-1)==(e-v)%(p-1) and s_dash==(s-u)):
				print("Final r': %d\n" %r_dash)
				break;

		print("Message= %s\ne'= %d s'= %d\n"%(message,e_dash,s_dash))

		data1=pickle.dumps([message,str(e_dash),str(s_dash)])
		sock.send(data1)

		status=sock.recv(1024).decode();
		print("Verification Status: %s"%status)

		time.sleep(10)




if __name__=="__main__":
	main()