import socket,pickle,time
import random,hashlib


def power(a,q,n):
	a=int(a)
	q=int(q)
	n=int(n)
	return pow(a,q,n);

def inverse_modulo(q,p):
	return power(q,p-2,p);


def get_sha(message):
	hash_obj=hashlib.sha1(message.encode())
	return int(hash_obj.hexdigest(),16)	

s=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
port=18000
s.bind(('127.0.0.1',port))
s.listen(5)
client,address=s.accept()
while True:

	#GETTING PUBKEY
	data=client.recv(1024)
	p,q,alpha,y=pickle.loads(data)
	print("Prime P: %d Prime q: %d alpha: %d y: %d\n" %(p,q,alpha,y));

	#SIGNEDMSG
	data1=client.recv(4096)
	message,e_dash,s_dash=pickle.loads(data1)
	e_dash=int(e_dash)
	s_dash=int(s_dash)
	print("Message= %s\ne'= %d s'= %d\n"%(message,e_dash,s_dash))

	##r*=α^s'.y^-e'
	r_star=((power(alpha,s_dash,p))*inverse_modulo(power(y,e_dash,p),p)%p)%p;

	print("r*: %d\n"%r_star);
	result=message+str(r_star);
	print("Concatenated m||r*: ",result);
	e_dashdash=get_sha(result);
	print("H(m||r*): %d e': %d\n"%(e_dashdash,e_dash));
	status='0';
	if(e_dashdash==e_dash):
		status='1';

	#VERSTATUS
	client.send(status.encode())


	#break
	# client.close()